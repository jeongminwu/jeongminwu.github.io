from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
import tensorflow.contrib.slim as slim
from utils import  flow_back_wrap
import collections



def l1_loss(Ipred, Iref, axis=[3]):
    return tf.reduce_mean(tf.reduce_sum(tf.abs(Ipred - Iref), axis=axis))  # L1 Norm


def l2_loss(Ipred, Iref, axis=[3]):
    return tf.reduce_mean(tf.reduce_sum(tf.square(Ipred - Iref), axis=axis))  # L2 Norm


def reconstruction_loss(Ipred, Iref):
    Ipred = tf.image.convert_image_dtype(Ipred, dtype=tf.uint8)
    Iref = tf.image.convert_image_dtype(Iref, dtype=tf.uint8)

    Ipred = tf.cast(Ipred, dtype=tf.float32)
    Iref = tf.cast(Iref, dtype=tf.float32)

    # tf.reduce_mean(tf.norm(tf.math.subtract(Ipred, Iref), ord=1, axis=[3]))
    return l1_loss(Ipred, Iref)



def wrapping_loss(frame0, frame1, frameT, F01, F10, Fdasht0, Fdasht1):
    return l1_loss(frame0, flow_back_wrap(frame1, F01)) + \
           l1_loss(frame1, flow_back_wrap(frame0, F10)) + \
           l1_loss(frameT, flow_back_wrap(frame0, Fdasht0)) + \
           l1_loss(frameT, flow_back_wrap(frame1, Fdasht1))



def smoothness_loss(F01, F10):
    deltaF01 = tf.reduce_mean(tf.abs(F01[:, 1:, :, :] - F01[:, :-1, :, :])) + tf.reduce_mean(
        tf.abs(F01[:, :, 1:, :] - F01[:, :, :-1, :]))
    deltaF10 = tf.reduce_mean(tf.abs(F10[:, 1:, :, :] - F10[:, :-1, :, :])) + tf.reduce_mean(
        tf.abs(F10[:, :, 1:, :] - F10[:, :, :-1, :]))
    return 0.5 * (deltaF01 + deltaF10)


# Model Helper Functions
def conv2d(batch_input, output_channels, kernel_size=3, stride=1, scope="conv", activation=None):
    with tf.variable_scope(scope):
        return slim.conv2d(batch_input, output_channels, [kernel_size, kernel_size], stride=stride,
                           data_format='NHWC',
                           weights_initializer=tf.contrib.layers.xavier_initializer(),
                           activation_fn=None)



def rrelu(input):
    return tf.nn.relu(input)


def max_pool(input, kernel_size, stride=2, scope="max_pool"):
    return tf.contrib.layers.max_pool2d(input, [kernel_size, kernel_size], stride, scope=scope)


def bilinear_upsampling(input, scale=2, scope="bi_upsample"):
    with tf.variable_scope(scope):
        shape = tf.shape(input)
        h, w = shape[1], shape[2]
        return tf.image.resize_bilinear(input, [scale * h, scale * w])


def encoder_block(inputs, output_channel, conv_kernel=3, pool_kernel=2, lrelu_alpha=0.1, scope="enc_block", pooler= None):
    with tf.variable_scope(scope):
        net = conv2d(inputs, output_channel, kernel_size=conv_kernel)
        conv = rrelu(net)
        if pooler =='max':
            conv = max_pool(conv, pool_kernel)
        return conv


#def decoder_block(input, skip_conn_input, output_channel, conv_kernel=3, up_scale=2, lrelu_alpha=0.1,
def decoder_block(input, output_channel, conv_kernel=3, up_scale=2, lrelu_alpha=0.1,

                  scope="dec_block"):
    with tf.variable_scope(scope):
        upsample = bilinear_upsampling(input, scale=up_scale)
        net = conv2d(upsample, output_channel, kernel_size=conv_kernel)
        net=rrelu((net))
        return net


def AUTO_ENC(inputs, output_channels, decoder_extra_input=None, first_kernel=3, second_kernel=3, scope='unet',
         output_activation=None, reuse=False):
    with tf.variable_scope(scope, reuse=reuse):
        with tf.variable_scope("encoder"):
            econv1  = encoder_block(inputs, 32, conv_kernel=first_kernel, scope="en_conv1")  # 256
            econv2  = encoder_block(econv1, 64, conv_kernel=second_kernel,pooler='max' , scope="en_conv2") # 128
            econv3  = encoder_block(econv2, 128, pooler='max', scope="en_conv3") # 64
        with tf.variable_scope("decoder"):
            net = decoder_block(econv3, 64, scope="dec_conv1")   # 128
            net = decoder_block(net, 32, scope="dec_conv2")   # 256
            net  = encoder_block(net, output_channels , conv_kernel=first_kernel, scope="voxellayer")  # 256
            net = tf.nn.tanh(net)

        return net



def Voxel_model(frame0, frame1, frameT, FLAGS, reuse=False, timestamp=0.5):
    # Define the container of the parameter
    if FLAGS is None:
        raise ValueError('No FLAGS is provided for generator')

    Network = collections.namedtuple('Network', 'total_loss, reconstruction_loss, \
                                                 pred_frameT ,Vt0, Ft0,Ft1,wrapping_loss,  smoothness_loss, \
                                                grads_and_vars, train, global_step, learning_rate')
    with tf.variable_scope("SloMo_model", reuse=reuse):
        with tf.variable_scope("flow_computation"):
            flow_comp_input = tf.concat([frame0, frame1], axis=3)


            net  = AUTO_ENC(flow_comp_input,output_channels=5,first_kernel=FLAGS.first_kernel,second_kernel=FLAGS.second_kernel)# 2 channel for each flow,
            F01 = net[:, :, :, 0:2]
            F10 = net[:, :, :, 2:4]
            mask = tf.expand_dims(net[:, :, :, 4], 3)
            mask = 0.5 * (1.0 + mask)
            mask = tf.tile(mask, [1, 1, 1, 3])

            print("Flow Computation Graph Initialized !!!!!! ")

        with tf.variable_scope("flow_interpolation"):
            Fdasht0 = (-1 * (1 - timestamp) * timestamp * F01) + (timestamp * timestamp * F10)
            Fdasht1 = ((1 - timestamp) * (1 - timestamp) * F01) - (timestamp * (1 - timestamp) * F10)

            deltaFt0 = F01*0.5
            deltaFt1=   F10 *0.5

            Ft0, Ft1 = Fdasht0 + deltaFt0, Fdasht1 + deltaFt1

            normalization_factor = 1 / ((1 - timestamp) * mask + timestamp * mask + FLAGS.epsilon)
            pred_frameT = tf.multiply((1 - timestamp) * mask, flow_back_wrap(frame0, Ft0)) + \
                          tf.multiply(timestamp * mask, flow_back_wrap(frame1, Ft1))
            pred_frameT = tf.multiply(normalization_factor, pred_frameT)

            print("Flow Interpolation Graph Initialized !!!!!! ")

            rec_loss = reconstruction_loss(pred_frameT, frameT)
            wrap_loss = wrapping_loss(frame0, frame1, frameT, F01, F10, Fdasht0, Fdasht1)
            smooth_loss = smoothness_loss(F01, F10)
            total_loss = FLAGS.reconstruction_scaling * rec_loss + \
                         FLAGS.wrapping_scaling * wrap_loss + \
                         FLAGS.smoothness_scaling * smooth_loss
    with tf.variable_scope("global_step_and_learning_rate", reuse=reuse):
        global_step = tf.contrib.framework.get_or_create_global_step()
        learning_rate = tf.train.exponential_decay(FLAGS.learning_rate, global_step, FLAGS.decay_step,
                                                   FLAGS.decay_rate,
                                                   staircase=FLAGS.stair)
        incr_global_step = tf.assign(global_step, global_step + 1)

    with tf.variable_scope("optimizer", reuse=reuse):
        with tf.control_dependencies(tf.get_collection(tf.GraphKeys.UPDATE_OPS)):
            tvars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='SloMo_model')
            optimizer = tf.train.AdamOptimizer(learning_rate, beta1=FLAGS.beta)
            grads_and_vars = optimizer.compute_gradients(total_loss, tvars)
            train_op = optimizer.apply_gradients(grads_and_vars)

    return Network(
        total_loss=total_loss,
        reconstruction_loss=rec_loss,
        smoothness_loss=smooth_loss,
        Ft0=Ft0,
        Ft1=Ft1,
        Vt0=mask,
        wrapping_loss=wrap_loss,
        pred_frameT=pred_frameT,
        grads_and_vars=grads_and_vars,
        train=tf.group(total_loss, incr_global_step, train_op),
        global_step=global_step,
        learning_rate=learning_rate
    )


def Voxel_model_infer(frame0, frame1, FLAGS, reuse=False, timestamp=0.5):
    # Define the container of the parameter
    if FLAGS is None:
        raise ValueError('No FLAGS is provided for generator')

    Network = collections.namedtuple('Network', 'pred_frameT')
    with tf.variable_scope("SloMo_model", reuse=reuse):
        with tf.variable_scope("flow_computation"):
            flow_comp_input = tf.concat([frame0, frame1], axis=3)
            net = AUTO_ENC(flow_comp_input, output_channels=5, first_kernel=FLAGS.first_kernel,second_kernel=FLAGS.second_kernel)  # 2 channel for each flow,
            F01 = net[:, :, :, 0:2]
            F10 = net[:, :, :, 2:4]
            mask = tf.expand_dims(net[:, :, :, 4], 3)

            mask = 0.5 * (1.0 + mask)
            mask = tf.tile(mask, [1, 1, 1, 3])

            print("Flow Computation Graph Initialized !!!!!! ")

        with tf.variable_scope("flow_interpolation"):
            Fdasht0 = (-1 * (1 - timestamp) * timestamp * F01) + (timestamp * timestamp * F10)
            Fdasht1 = ((1 - timestamp) * (1 - timestamp) * F01) - (timestamp * (1 - timestamp) * F10)

            deltaFt0 = F01 * 0.5
            deltaFt1 = F10 * 0.5

            Ft0, Ft1 = Fdasht0 + deltaFt0, Fdasht1 + deltaFt1

            normalization_factor = 1 / ((1 - timestamp) * mask + timestamp * mask + FLAGS.epsilon)
            pred_frameT = tf.multiply((1 - timestamp) * mask, flow_back_wrap(frame0, Ft0)) + \
                          tf.multiply(timestamp * mask, flow_back_wrap(frame1, Ft1))
            pred_frameT = tf.multiply(normalization_factor, pred_frameT)

        print("Flow Interpolation Graph Initialized !!!!!! ")


    return Network(pred_frameT=pred_frameT)
