


train   (디렉토리확인)

      dvf.py 
      
      
inference   ( 코드에서 디렉토리 수정필요)
 
         voxel_vidow.py
         
         
         
끝 