## Setup
Tensorflow 2.1. 

##infer
```bash
python Voxel-flow/inference.py --video_path path/to/source/video  --output_path path/to/slomo/video --model path/to/checkpoint/ckpt-111 --n_frames 1 --fps 60
```

## Train

```bash
python Voxel-flow/train.py path/to/destination --model path/to/checkpoints --epochs 100 --batch_size 12


체크포인트 재사용 가능 디렉토리 같게

```bash
tensorboard --logdir log --port 6006
```
