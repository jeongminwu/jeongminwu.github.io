import tensorflow as tf

import config


class Losses:
    def __init__(self):
        self.mae = tf.keras.losses.MeanAbsoluteError()
        self.mse = tf.keras.losses.MeanSquaredError()
        model = tf.keras.applications.VGG16(weights="imagenet", include_top=False)
        self.vgg16 = tf.keras.Model(
            model.inputs, model.get_layer("block4_conv3").output, trainable=False
        )

    @tf.function
    def reconstruction_loss(self, y_true, y_pred):
        """
        Reconstruction loss models how good
        the reconstruction of the intermediate frames
        :param y_true: Ground truth values
        :param y_pred: The predicted values
        :return:
        """
        return self.mae(y_true, y_pred)

    @tf.function
    def perceptual_loss(self, y_true, y_pred):
        """
        Perceptual loss preserves details of the predictions
        and make interpolated frames sharper
        :param y_true: Ground truth values
        :param y_pred: The predicted values
        :return:
        """
        y_true = self.extract_feat(self.vgg16, y_true)
        y_pred = self.extract_feat(self.vgg16, y_pred)
        return self.mse(y_true, y_pred)

    @tf.function
    def extract_feat(self, feat_extractor, inputs):
        """
        :param feat_extractor:
        :param inputs:
        :return:
        """
        feats = inputs
        for layer in feat_extractor.layers:
            feats = layer(feats)
        return feats


    @tf.function
    def _compute_delta(self, frame):
        """

        :param frame:
        :return:
        """
        x = tf.reduce_mean(tf.abs(frame[:, 1:, :, :] - frame[:, :-1, :, :]))
        y = tf.reduce_mean(tf.abs(frame[:, :, 1:, :] - frame[:, :, :-1, :]))
        return x + y

    @tf.function
    def compute_losses(self, predictions, inputs, frames_t):
        """
        Compute the losses (reconstruction loss, perceptual loss, smoothness loss,
        warping loss and a comination of all the losses.
        :param predictions: the predictions of the models
        :param loss_values: loss values from the GradientTape
        :param inputs: frames in input
        :param frames_t: target frames
        :return: the losses
        """
        frames_0, frames_1, _ = inputs

        # unpack loss variables
        #f_01, f_10 = loss_values[:2]
        #backwarp_frames = loss_values[2:]

        rec_loss = self.reconstruction_loss(frames_t, predictions)
        perc_loss = self.perceptual_loss(frames_t, predictions)
        #smooth_loss = self.smoothness_loss(f_01, f_10)
        #warp_loss = self.warping_loss(frames_0, frames_t, frames_1, backwarp_frames)

        total_loss = (
            config.REC_LOSS * rec_loss
            + config.PERCEP_LOSS * perc_loss
        )
        return total_loss, rec_loss, perc_loss
