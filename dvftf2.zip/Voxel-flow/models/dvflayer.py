import tensorflow as tf

class CAE(tf.keras.layers.Layer):
    def __init__(self, out_filters, name="CAE", **kwargs):
        super(CAE, self).__init__(name=name, **kwargs)
        self.out_filters = out_filters

    def build(self, input_shape):
        self.conv1 = tf.keras.layers.Conv2D(
            filters=64, kernel_size=5, strides=1, padding="same",activation='relu'
        )
        self.encoder2 = Encoder(128, 5)
        self.encoder3 = Encoder(256, 3)
        self.encoder4 = Encoder(512, 3) #bottle neck <-^_^
        self.decoder1 = Decoder(256,3)
        self.decoder2 = Decoder(128,5)
        self.decoder3 = Decoder(64,5)
        self.voxellayer = tf.keras.layers.Conv2D(
            filters=self.out_filters, kernel_size=5, strides=1, padding="same")

    def call(self, inputs, **kwargs):
        x_enc = self.conv1(inputs) #256
        x_enc = self.encoder2(x_enc) # 128
        x_enc = self.encoder3(x_enc)# 64
        x_enc = self.encoder4(x_enc) # 32
        x_dec = self.decoder1(x_enc)#64
        x_dec = self.decoder2(x_dec)#128
        x_dec = self.decoder3(x_dec)#256
        x_dec = self.voxellayer(x_dec)
        x_dec = tf.keras.activations.tanh(x_dec)
        return x_dec


class Encoder(tf.keras.layers.Layer):
    def __init__(self, filters, kernel_size, **kwargs):
        super(Encoder, self).__init__(**kwargs)
        self.filters = filters
        self.kernel_size = kernel_size

    def build(self, input_shape):
        self.conv1 = tf.keras.layers.Conv2D(
            filters=self.filters,
            kernel_size=self.kernel_size,
            strides=1,
            padding="same",activation='relu'
        )
        self.max_pool = tf.keras.layers.MaxPool2D()

    def call(self, inputs, **kwargs):
        x = self.max_pool(inputs)
        x = self.conv1(x)
        return x


class Decoder(tf.keras.layers.Layer):

    def __init__(self, filters,kernel_size, **kwargs):
        super(Decoder, self).__init__(**kwargs)
        self.filters = filters
        self.kernel_size = kernel_size

    def build(self, input_shape):
        self.conv1 = tf.keras.layers.Conv2D(
            filters=self.filters, kernel_size=self.kernel_size, strides=1, padding="same",activation='relu'
        )
        self.interpolation = tf.keras.layers.UpSampling2D(interpolation="bilinear")


    def call(self, inputs, **kwargs):
        x = inputs
        x = self.interpolation(x)
        x = self.conv1(x)
        return x

class Bilinear(tf.keras.layers.Layer):
    def __init__(self, name='Bilinear',**kwargs):
        super(Bilinear, self).__init__(name=name,**kwargs)
    def call(self,im, x, y, **kwargs):
        x = tf.reshape(x, [-1])  # flaten
        y = tf.reshape(y, [-1])

        # constants
        num_batch = tf.shape(im)[0]
        _, height, width, channels = im.get_shape().as_list()

        x = tf.cast(x,'float32')
        y = tf.cast(y,'float32')

        height_f = tf.cast(height, 'float32')
        width_f = tf.cast(width, 'float32')
        zero = tf.constant(0, dtype=tf.int32)

        max_x = tf.cast(tf.shape(im)[2] - 1, 'int32')
        max_y = tf.cast(tf.shape(im)[1] - 1, 'int32')
        x = (x + 1.0) * (width_f - 1.0) / 2.0
        y = (y + 1.0) * (height_f - 1.0) / 2.0
        #print(width_f)

        # Sampling
        x0 = tf.cast(tf.floor(x), 'int32')
        x1 = x0 + 1
        y0 = tf.cast(tf.floor(y), 'int32')
        y1 = y0 + 1

        x0 = tf.clip_by_value(x0, zero, max_x)
        x1 = tf.clip_by_value(x1, zero, max_x)
        y0 = tf.clip_by_value(y0, zero, max_y)
        y1 = tf.clip_by_value(y1, zero, max_y)

        dim2 = width
        dim1 = width * height

        # Create base index
        base = tf.range(num_batch) * dim1
        base = tf.reshape(base, [-1, 1])
        base = tf.tile(base, [1, height * width])
        base = tf.reshape(base, [-1])

        base_y0 = base + y0 * dim2
        base_y1 = base + y1 * dim2
        idx_a = base_y0 + x0
        idx_b = base_y1 + x0
        idx_c = base_y0 + x1
        idx_d = base_y1 + x1

        # Use indices to look up pixels
        im_flat = tf.reshape(im, tf.stack([-1, channels]))
        im_flat = tf.cast(im_flat,'float32')
        pixel_a = tf.gather(im_flat, idx_a)
        pixel_b = tf.gather(im_flat, idx_b)
        pixel_c = tf.gather(im_flat, idx_c)
        pixel_d = tf.gather(im_flat, idx_d)

        # Interpolate the values
        x1_f = tf.cast(x1,'float32')
        y1_f = tf.cast(y1,'float32')

        wa = tf.expand_dims((x1_f - x) * (y1_f - y), 1)
        wb = tf.expand_dims((x1_f - x) * (1.0 - (y1_f - y)), 1)
        wc = tf.expand_dims((1.0 - (x1_f - x)) * (y1_f - y), 1)
        wd = tf.expand_dims((1.0 - (x1_f - x)) * (1.0 - (y1_f - y)), 1)

        output = tf.add_n([wa * pixel_a, wb * pixel_b, wc * pixel_c, wd * pixel_d])
        output = tf.reshape(output, shape=tf.stack([num_batch, height, width, channels]))
        return output


