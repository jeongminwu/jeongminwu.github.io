import numpy as np
import tensorflow as tf

from models import dvflayer

class VoxelNet(tf.keras.Model):

    def __init__(self, n_frames=12, name="VoxelNet", **kwargs):
        super(VoxelNet, self).__init__(name=name, **kwargs)
        self.flow_comp_layer = dvflayer.CAE(3, name="flow_comp")
        self.b = [dvflayer.Bilinear(name='bilinear')] * 2

    def call(self, inputs, training=False, **kwargs):
        frames_0, frames_1, _ = inputs
        flow_input = tf.concat([frames_0, frames_1], axis=3)
        net = self.flow_comp_layer(flow_input)
        flow = net[:, :, :, 0:2]

        mask = tf.expand_dims(net[:, :, :, 2], 3)
        height=tf.shape(frames_0)[1]
        width=tf.shape(frames_0)[2]
        x_t = tf.matmul(
          tf.ones(shape=tf.stack([height, 1])),
          tf.transpose(
            tf.expand_dims(
              tf.linspace(-1.0, 1.0, width), 1), [1, 0]))
        y_t = tf.matmul(
          tf.expand_dims(
            tf.linspace(-1.0, 1.0, height), 1),
          tf.ones(shape=tf.stack([1, width])))
        x_t_flat = tf.reshape(x_t, (1, -1))
        y_t_flat = tf.reshape(y_t, (1, -1))
        grid_x = tf.reshape(x_t_flat, [1, height, width])
        grid_y = tf.reshape(y_t_flat, [1, height, width])
 
        grid_x = tf.tile(grid_x, [tf.shape(frames_0)[0], 1, 1])
        grid_y = tf.tile(grid_y, [tf.shape(frames_0)[0], 1, 1])

        #print(tf.shape(frames_0)[0])

        flow =0.5* flow

        coor_x_1 = grid_x + flow[:, :, :, 0]
        coor_y_1 = grid_y + flow[:, :, :, 1]
        coor_x_2 = grid_x - flow[:, :, :, 0]
        coor_y_2 = grid_y - flow[:, :, :, 1]
        output_1 = self.b[0](frames_0, coor_x_1, coor_y_1)
        output_2 = self.b[1](frames_1, coor_x_2, coor_y_2)
        mask = (1.0 + mask)*0.5
        mask = tf.tile(mask, [1, 1, 1, 3])
        pred_frameT = tf.multiply(mask, output_1) + tf.multiply(1.0 - mask, output_2)
        #print("flow compu complet ")
        return pred_frameT
