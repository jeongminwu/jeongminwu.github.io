import tensorflow as tf

import dvfconfig


class Losses:
    def __init__(self):
        self.mae = tf.keras.losses.MeanAbsoluteError()
        self.mse = tf.keras.losses.MeanSquaredError()
        model = tf.keras.applications.VGG16(weights="imagenet", include_top=False)
        self.vgg16 = tf.keras.Model(
            model.inputs, model.get_layer("block4_conv3").output, trainable=False
        )
    @tf.function
    def reconstruction_loss(self, y_true, y_pred):
        return self.mae(y_true, y_pred)

    @tf.function
    def perceptual_loss(self, y_true, y_pred): # GT, PRed
        y_true = self.extract_feat(self.vgg16, y_true)
        y_pred = self.extract_feat(self.vgg16, y_pred)
        return self.mse(y_true, y_pred)

    @tf.function
    def extract_feat(self, feat_extractor, inputs):

        feats = inputs
        for layer in feat_extractor.layers:
            feats = layer(feats)
        return feats

    @tf.function
    def compute_losses(self, predictions, inputs, frames_t):

        frames_0, frames_1, _ = inputs

        rec_loss = self.reconstruction_loss(frames_t, predictions)
        perc_loss = self.perceptual_loss(frames_t, predictions)

        total_loss = (
                dvfconfig.REC_LOSS * rec_loss
                + dvfconfig.PERCEP_LOSS * perc_loss
        )
        return total_loss, rec_loss, perc_loss
